def do_upgrade(env, ver, cursor):
    pass # Change the database schema here